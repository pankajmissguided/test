
var viewports =["macbook-15", "iphone-6"];
var regions = ['us', 'fr', 'au', 'es', 'de', 'eu', 'es', 'ie', 'pl']; 
// dynamic options have been considered such as getting the keys of the websiteUrls.json
// however that the risk this presents if URLS are missing could be an issue.
// Also dynamically generating the array assumes no variance
// Comments are also in the JSON which will cause issues.

beforeEach(() => {
    cy.server();
})

describe('Missguided Product Page', () => {
    viewports.forEach((viewport) => {
        context(viewport, () => {
            regions.forEach((region) => {
                context("Add product to bag when region = " + region, () => {
                    it("Should return a 200 status after clicking add to bag", () => {
                        cy.viewport(viewport);
                        cy.visitProductPage(region);
                        cy.addToBag();
                    });
                });
            });
        });
    });
});