var viewports =["macbook-15", "iphone-6"];
var regions = ['us', 'fr', 'au', 'es', 'de', 'eu', 'es', 'ie', 'pl']; 

// Tests are de-scoped until cypress fixes issues with state clearing between tests

xdescribe('Missguided Product Page', () => {
    viewports.forEach((viewport) => {
        context(viewport, () => {
            regions.forEach((region) => {
                context('user can register on missguided on region = ' + region, () => {
                    it('should let a new user register', () => {
                        cy.viewport(viewport);
                        cy.visitLoginPage(region);
                        cy.get('.account-login__label--last').click();
                        cy.loginPageRegisterFormfill();
                        cy.get('#register').click();
                        cy.get('.success-msg span').should('be.visible');
                    });
                });
            });
        });
    });
});