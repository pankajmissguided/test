import faker from 'faker';

beforeEach( () => {
    cy.server();
    Cypress.on('uncaught:exception', (err, runnable) => { // there is an uncaught error in category page
     console.log(err);   
     return false;
    });
});

var viewports =["macbook-15", "iphone-6"];

var position = Math.floor((Math.random() * 40) + 1);
 
var menu = "Shop All";

var region = "mennace";

describe("Mennace E2E checkout", ()=>{
  viewports.forEach( (viewport) => {
    context("Guest user can place an order by choosing delivery option and using stripe card details", ()=>{
        it("should allow user to place an order using stripe card details", ()=>{
            cy.viewport(viewport);
            cy.visitHomePage(region);
            cy.wait(5000);
            cy.open_main_menu();
            cy.wait(5000);
            cy.main_menu_nav_without_sub_menu(menu);
            cy.selectProduct(position);
            cy.addToBag();
            cy.filled_bag_icon();
            cy.addEmailForGuest();
            cy.enterCheckoutUserData();
            cy.enterCapturePlusData();
            cy.chooseDeliveryOption();
            cy.enterStripeDetails();
            cy.placeOrder();
            cy.get('.checkout__order-number');
        });
    });

    context("Registered user can place an order by choosing delivery option and using stripe card details", ()=>{
        it("should allow user to place an order using stripe card details", ()=>{
            cy.viewport(viewport);
            cy.visitLoginPage(region);
            cy.mennaceRegistration();
            cy.wait(5000);
            cy.open_main_menu();
            cy.wait(5000);
            cy.main_menu_nav_without_sub_menu(menu);
            cy.selectProduct(position);
            cy.addToBag();
            cy.filled_bag_icon();
            cy.enterCheckoutUserData();
            cy.enterCapturePlusData();
            cy.chooseDeliveryOption();
            cy.enterStripeDetails();
            cy.placeOrder();
            cy.get('.checkout__order-number');
        });
    });

    context("Guest user can place an order by choosing C&C option and using stripe card details", ()=>{
        it("should allow user to place an order using C&C and stripe card details", ()=>{
            cy.viewport(viewport);
            cy.visitHomePage(region);
            cy.wait(5000);
            cy.open_main_menu();
            cy.wait(5000);
            cy.main_menu_nav_without_sub_menu(menu);
            cy.selectProduct(position);
            cy.addToBag();
            cy.filled_bag_icon();
            cy.addEmailForGuest();
            cy.get('#checkout-tab-click-and-collect')
              .click();
            cy.get('#clickcollect\\:firstname') 
              .type(faker.name.firstName(), {force: true});
            cy.get('#clickcollect\\:lastname') 
              .type(faker.name.lastName(), {force: true});      
            cy.enterCheckoutUserData();
            cy.enterClickAndCollectInfo();
            cy.clickAndCollectStore();
            cy.enterStripeDetails();
            cy.enterBillingAddress();
            cy.placeOrder();
            cy.get('.checkout__order-number');
        });
    });

    context("Registered user can place an order by choosing C&C option and using stripe card details", ()=>{
        it("should allow user to place an order using C&C and stripe card details", ()=>{
            cy.viewport(viewport);
            cy.visitLoginPage(region);
            cy.mennaceRegistration();
            cy.wait(5000);
            cy.open_main_menu();
            cy.wait(5000);
            cy.main_menu_nav_without_sub_menu(menu);
            cy.selectProduct(position);
            cy.addToBag();
            cy.filled_bag_icon();
            cy.get('#checkout-tab-click-and-collect')
              .click();
            cy.enterCheckoutUserData();
            cy.enterClickAndCollectInfo();
            cy.clickAndCollectStore();
            cy.enterStripeDetails();
            cy.enterBillingAddress();
            cy.placeOrder();
            cy.get('.checkout__order-number');
        });
    });
  });

});