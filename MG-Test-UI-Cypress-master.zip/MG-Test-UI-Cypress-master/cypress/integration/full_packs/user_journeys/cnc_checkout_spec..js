import faker from 'faker';

let pcaExtraResponse = {
    "Items":[
        {
            "IpAddress":"62.254.12.218",
            "Iso2":"GB",
            "Iso3":"GBR",
            "Country":"UNITED KINGDOM"}
        ]
    };

before( () => {
    Cypress.on('uncaught:exception', (err, runnable) => {
        console.log(err);
        return false;
      })
});

var viewports = ["macbook-15", "iphone-6"];

describe('Missguided E2E: User Checkout', () => {
    beforeEach( function () {
        cy.server();
        cy.route('GET', /Extras\/Web\/Ip2Country/, pcaExtraResponse);
        cy.route('POST', /webapps\/hermes\/api\/logger/, {status: 503});
        cy.route('POST', /checkout\/securecheckout\/getPersistentBasket/).as('updateCart');
        cy.visit('/');
        cy.clearCookie('frontend');
    });
    viewports.forEach( (viewport) => {
        context('Registered user can place an order with C&C as a delivery method', ()=> {
            it('Should allow a registered user to checkout with C&C as a delivery method',()=>{
                cy.viewport(viewport);
                cy.createUser();
                cy.visitProductPage();
                cy.addToBag();
                cy.get('.mini-bag__item-qty')
                    .click();
                cy.get('#checkout-tab-click-and-collect')
                    .click();
                cy.enterCheckoutUserData();
                cy.enterClickAndCollectInfo();
                cy.get('.click-collect__result > .click-collect__list > li:first-child').click();
                cy.wait('@updateCart')
                cy.enterStripeDetails();
                cy.enterBillingAddress();
                cy.get('.js-capture-plus-address-box-billing-container')
                    .should('be.visible');
                cy.placeOrder();
            });
        });
        context('Guest user can place an order with C&C as a delivery method', () => {
            it('Should allow a Guest user to checkout with C&C as a delivery method', () => {
                cy.viewport(viewport);
                cy.visitProductPage();
                cy.addToBag();
                cy.get('.mini-bag__item-qty')
                    .click();
                cy.addEmailForGuest();
                cy.get('#checkout-tab-click-and-collect')
                  .click();
                cy.get('#clickcollect\\:firstname') 
                    .type(faker.name.firstName(), {force: true});
                cy.get('#clickcollect\\:lastname') 
                    .type(faker.name.lastName(), {force: true});  
                cy.enterCheckoutUserData();
                cy.enterClickAndCollectInfo();
                cy.get('.click-collect__result > .click-collect__list > li:first-child')
                  .click();
                cy.wait('@updateCart');
                cy.enterStripeDetails();
                cy.enterBillingAddress();
                cy.get('.js-capture-plus-address-box-billing-container')
                  .should('be.visible');
                cy.placeOrder();
            });
        });
    });
});