import faker from 'faker';

let pcaExtraResponse = {
    "Items":[
        {
            "IpAddress":"62.254.12.218",
            "Iso2":"GB",
            "Iso3":"GBR",
            "Country":"UNITED KINGDOM"}
        ]
    };

before( () => {
    Cypress.on('uncaught:exception', (err, runnable) => {
        console.log(err);
        return false;
      })
});

var viewports = ["macbook-15", "iphone-6"];

describe('Missguided E2E: User Checkout', () => {
    beforeEach( function () {
        cy.server();
        cy.route('GET', /Extras\/Web\/Ip2Country/, pcaExtraResponse);
        cy.route('POST', /webapps\/hermes\/api\/logger/, {status: 503});
        cy.route('POST', /checkout\/securecheckout\/getPersistentBasket/).as('updateCart');
        cy.visit('/');
        cy.clearCookie('frontend');
    });
    viewports.forEach( (viewport) => {
        context('guest user can place an order', () => {
            it('Should allow a guest user to checkout', () => {
                cy.viewport(viewport);
                // PRODUCT PAGE
                cy.visitProductPage();
                cy.addToBag();
                // NAVIGATE TO CHECKOUT
                cy.get('.mini-bag__item-qty')
                    .click();
                // CHECKOUT PAGE
                cy.addEmailForGuest();
                // CHECKOUT::USER DETAILS
                cy.enterCheckoutUserData();
                // CHECKOUT::CAPTUREPLUS
                cy.enterCapturePlusData();
                //CHECKOUT::SELECTSHIPPING 
                cy.chooseDeliveryOption();
                cy.wait('@updateCart')
                //CHECKOUT::STRIPE
                cy.enterStripeDetails();
                //CHECKOUT::CONFIRM
                cy.placeOrder();
                cy.get('.checkout__order-number');
            });
        });
        context('Registered user can place an order', () => {
            it('Should allow a registered user to checkout', () => {
                cy.viewport(viewport);
                cy.createUser();
                cy.visitProductPage();
                cy.addToBag();
                cy.get('.mini-bag__item-qty')
                  .click();
                cy.enterCheckoutUserData();
                cy.enterCapturePlusData();
                cy.chooseDeliveryOption();
                cy.wait('@updateCart')
                cy.enterStripeDetails();
                cy.placeOrder();
                cy.get('.checkout__order-number');
            });
        });
    });
});