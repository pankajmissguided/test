beforeEach( () => {
    cy.server();
});

var viewports =["macbook-15", "iphone-6"];



describe('Missguided GDPR', ()=>{
  viewports.forEach( (viewport) => {
    
    context('GDPR CMS Page', ()=>{
      xit('GDPR CMS should be visible to user and by clicking on tell me more about my deets should redirect to the corresponding page ', ()=>{
         cy.viewport(viewport);
         cy.visit('/privacy-notices');
         cy.cmsPage();
      });
    }); 
    
    
    context('GDPR message on checkout page', ()=>{
      it('GDPR message should be displayed in the checkout page', ()=>{
         cy.viewport(viewport);
         cy.visitProductPage();
         cy.gdprCheckoutMessage();
      });
    });
  
  });    
});