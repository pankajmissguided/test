beforeEach( () => {
    cy.server();
});

var viewports =["macbook-15", "iphone-6"];

describe('Missguided Product Page', () => {
    viewports.forEach( (viewport) => {
        context(viewport, () => {
            context('add  product to bag', () => {
                it('Should allow a user to add a product to bag', () => {
                    cy.viewport(viewport);
                    cy.visitProductPage();
                    cy.route('POST', /ajax\/cart\/add/)
                        .as('getLogin')
                    var sizes= [];
                    cy.get('.sizes-list__item span').then((size) => {
                        let sizes=size;
                        var selectSize= sizes[Math.floor(Math.random() * sizes.length)];
                        console.log(selectSize);
                        cy.get('.sizes-list__item').find(selectSize).click();
                    });   
                    cy.addToBag();
                });
            });
            context('product-image slider', () => {
                it('should allow user to slide all the product images', () => {
                    cy.viewport(viewport);
                    cy.visitProductPage();
                    cy.get(".product-images-list__item").then((images) => {
                        cy.log(images)
                        let c = images.length;
                        let i;
                        for(i=0; i<c; i++){
                            cy.get('.ui-carousel__nav--next').click();
                            cy.get('.product-images-list__item--active').click();
                        }
                    })
                });
            });
            context('product page play video', () => {
                it('should allow user to play video and once the video is played should revert back to product image', () => {
                    cy.viewport(viewport);
                    cy.visitProductPage();
                    cy.get('.js-view-product-video')
                        .click();
                    cy.get('.product-video-list')
                        .should('be.visible');
                    cy.get('.view-product-media--images')
                        .should('have.text', "\n        \n            \n        \n        View Images    ");
                    cy.get('.product-video-list', {timeout: 15000})
                        .should('not.be.visible');
                    cy.get('.view-product-media--images')
                        .should('be.visible');
                    cy.get('.js-view-product-video').should('have.text', "\n        \n            \n        \n        Play Video    ");  
                });
            });

            context('read more and read less link text in product page', () => {
                it('should allow user to minimise or expand the product description', () => {
                    cy.viewport(viewport);
                    cy.visitProductPage();
                    cy.get('.product-essential__information-see-more-link')
                        .should('have.text', "Read more")
                        .click()
                        .should('have.text', "Read less")
                        .click()
                        .should('have.text', "Read more")
                });
            });

            context('wishlist', ()=>{
                it('should allow a user to add a product to wishlist only once', ()=>{
                    cy.viewport(viewport);
                    cy.createUser();
                    cy.visitProductPage();
                    cy.get('#product_addtocart_form').find('.wishlist-button__text').click();
                    cy.get('#wishlist-adding-copy').should('have.text', "Adding to Wishlist...");
                    cy.get('#wishlist-success-copy').should('have.text', "Item Added!");
                    cy.get('#product_addtocart_form').find('.wishlist-button__text').click();
                    cy.get('.wishlist-alert').should('have.text', "\n    Oops…\n    You’ve already saved this to your wish list\n"); 
                });
            });

            context('Adding a product to bag from shop this look option', ()=> {
                it("should allow user to add a product from shop this look to bag", ()=> {
                    cy.visitProductPage();
                    cy.get(".js-shop-the-look").should('have.text', "\n        \n            \n        \n        Shop This Look    ").click();
                    cy.get('.modal > .col2-set > .col-2 > div').then((products) => {
                        let val = products;
                        var selectVal = val[Math.floor(Math.random() * val.length)];
                        console.log(selectVal);
                        cy.get('.shop-the-look__products').find(selectVal).within(() =>{
                            cy.get('.size-select > option').then((sizes) => { 
                                let size = sizes;
                                var selectSize = size[Math.floor(Math.random() * size.length)];
                                console.log(selectSize);
                                cy.get('.size-select').select(selectSize.value); 
                                cy.get('.addToBasketButton').click();
                            });
                        });
                    });    
                });
            });
        });        
    });
});
  

