import faker from "faker";

beforeEach( () => {
    cy.server();
});

var invalidEmail = faker.name.firstName() + '.com';

var viewports =["macbook-15", "iphone-6"];

describe('Missguided Newsletter sign up', ()=> {
       context('Desktop newsletter sign up from footer with valid email address', ()=> {
          it('should allow user to sign up newsletter from footer with valid email address', ()=> {
            var signupEmail = faker.name.firstName() + faker.name.lastName() + '@example.com';
            cy.viewport("macbook-15");
            cy.visit("");
            cy.footer_subscription(signupEmail);
            cy.get('.footer')
              .within(()=> {
                cy.get('#newsletter-signup-result')
                  .should('have.text', "Thank you for your subscription."); 
              });  
          });
        });

        context('mobile newsletter sign up from footer with valid email address', ()=> {
          it('should allow user to sign up newsletter from footer with valid email address', ()=> {
            var mob_sign_up = faker.name.firstName() + faker.name.lastName() + '@example.com';
            cy.viewport("iphone-6");
            cy.visit("");
            cy.footer_subscription(mob_sign_up);
            cy.get('.footer')
              .within(()=> {
                cy.get('#newsletter-signup-result')
                  .should('have.text', "Thank you for your subscription."); 
              });  
          });
        });

        context('desktop newsletter signup from main menu with valid email address', ()=>{
          it('should allow user to sign up newsletter from main menu with valid email address', ()=>{
             var signupEmails = faker.name.firstName() + faker.name.lastName() + '@example.com';
             cy.viewport("macbook-15");
             cy.visit("");
             cy.wait(5000);
             cy.mainMenu_newsletter();
             cy.newsletter_subscription_mainMenu(signupEmails);
             cy.get('.form__newsletter')
               .within(()=>{
                  cy.get('#newsletter-signup-result')
                    .should('have.text', "Thank you for your subscription.");
               });
          });
        });
    
        context('mobile newsletter signup from main menu with valid email address', ()=>{
          it('should allow user to sign up newsletter from main menu with valid email address', ()=>{
             var mob_sign_ups = faker.name.firstName() + faker.name.lastName() + '@example.com';
             cy.viewport("iphone-6");
             cy.visit("");
             cy.wait(5000);
             cy.mainMenu_newsletter();
             cy.newsletter_subscription_mainMenu(mob_sign_ups);
             cy.get('.form__newsletter')
               .within(()=>{
                  cy.get('#newsletter-signup-result')
                    .should('have.text', "Thank you for your subscription.");
               });
          });
        });

      viewports.forEach( (viewport) => {
        
        context('newsletter sign up from footer by leaving the email field as empty', ()=>{
          it('should not allow user to sign up from footer by leaving the email field as empty', ()=>{
            cy.viewport(viewport);
            cy.visit("");
            cy.get('.footer')
              .within(()=>{
                cy.get('.js-newsletter-input')
                  .type('{enter}');
                cy.get('#newsletter-signup-result')
                  .should('have.text', "Please enter an email address."); 
              });
          });
        });
        
        context('newsletter sign up from footer with invalid email address', ()=> {
            it('should not allow user to sign up from footer with invalid email address', ()=> {
              cy.viewport(viewport);
              cy.visit("");
              cy.footer_subscription(invalidEmail);
              cy.get('.footer')
                .within(()=> {
                  cy.get('#newsletter-signup-result')
                    .should('have.text', "There was a problem with the subscription: Please enter a valid email address.");   
                });
            });
        });
        
        context('newsletter sign up from footer with already subscribed email', ()=> {
          it('should not allow user to sign up newsletter from footer with already subscribed email', ()=> {
            const subscribed = faker.name.firstName() + faker.name.lastName() + '@example.com';
            cy.viewport(viewport);
            cy.visit("");
            cy.footer_subscription(subscribed)
            cy.get('.js-newsletter-input')
              .clear({force : true});  
            cy.footer_subscription(subscribed);
            cy.log(subscribed);
            cy.get('.footer')
              .within(()=> {
                cy.get('#newsletter-signup-result')
                  .should('have.text', "You are already subscribed."); 
              })  
          });
        });

        context('newsletter sign up from main menu with invalid email address', ()=>{
          it('should not allow user to sign up from main menu with invalid email address', ()=>{
            cy.viewport(viewport);
            cy.visit("");
            cy.wait(5000);
            cy.mainMenu_newsletter();
            cy.newsletter_subscription_mainMenu(invalidEmail);
             cy.get('.form__newsletter')
               .within(()=>{
                 cy.get('#newsletter-signup-result')
                   .should('have.text', "There was a problem with the subscription: Please enter a valid email address.");
               });     
          });
        });

        context('newsletter sign up from main menu with already subscribed email', ()=>{
          it('should not allow user to sign up newsletter from main mneu with already subscribed email', ()=>{
            const alreadySubscribed = faker.name.firstName() + faker.name.lastName() + '@example.com'; 
            cy.viewport(viewport);
            cy.visit("");
            cy.wait(5000);
            cy.mainMenu_newsletter();
            cy.newsletter_subscription_mainMenu(alreadySubscribed);
            cy.get('.newsletter-overlay-content > .form__newsletter > #newsletter-validate-detail > fieldset > .form__list > .form__field > .form__input > .left > .newsletter-input')
              .clear({force : true});
            cy.newsletter_subscription_mainMenu(alreadySubscribed);    
            cy.get('.form__newsletter')
               .within(()=>{
                 cy.get('#newsletter-signup-result')
                   .should('have.text', "You are already subscribed.");
               });    
          });
        });
       
        context('newsletter sign up from main menu by leaving the by leaving the email field as empty', ()=>{
          it('should not allow user to sign up from footer by leaving the email field as empty', ()=>{
            cy.viewport(viewport);
            cy.visit("");
            cy.wait(5000);
            cy.mainMenu_newsletter();
            cy.get('.newsletter-overlay-content > .form__newsletter > #newsletter-validate-detail > fieldset > .form__list > .form__field > .form__input > .left > .newsletter-input')
              .type('{enter}');
            cy.get('.form__newsletter')
              .within(()=>{  
                cy.get('#newsletter-signup-result')
                  .should('have.text', "Please enter an email address."); 
                   
              });
          });
        });

      
      
      });

    
       
    });
