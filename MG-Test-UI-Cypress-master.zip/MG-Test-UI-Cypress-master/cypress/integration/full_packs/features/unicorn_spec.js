var viewports =["macbook-15", "iphone-6"];

describe("Hackathon Workshop", () => {
    viewports.forEach( (viewport) => {
        context(viewport, () => {
            context("Unicorn Delivery UK", () => {
                it("Should allow a user to add to bag", () => {
                    cy.viewport(viewport);
                    cy.server();
                    cy.route('POST', /ajax\/cart\/add/).as("ajaxAddToBag")
                    cy.visit("/unicorn-class-premier-delivery");
                    cy.get("#unicorn-terms__checkbox").check({force:true});
                    cy.get('#add-to-cart').click();
                    cy.wait('@ajaxAddToBag').then((xhr) => {
                        expect(xhr.status).to.equal(200);
                    });
                });
                it("Should not allow a user to add to back with out confirming TnCs", () => {
                    cy.viewport(viewport);
                    cy.visit("/unicorn-class-premier-delivery");
                    cy.get('.button').should("be.disabled");
                });
                it("Allow users to access the faq", () => {
                    cy.viewport(viewport);
                    cy.visit("/unicorn-class-premier-delivery");
                    cy.get('.product-options__link').click();
                    cy.get('.modal').should("be.visible");
                });
                it("should give the user free delivery in the checkout", () => {
                    cy.viewport(viewport);
                    cy.server();
                    cy.createUser();
                    cy.addUnicornToBag();
                    cy.addProductToBag();
                    cy.visit("/checkout/securecheckout/");
                    cy.enterCheckoutUserData();
                    cy.enterCapturePlusData();
                    cy.get('[data-method="Unicorn Class (UK Next Day Delivery)"] > label > div > span', {timeout: 10000}).should('have.text', "£0.00");
                });
            });
        });
    });
});