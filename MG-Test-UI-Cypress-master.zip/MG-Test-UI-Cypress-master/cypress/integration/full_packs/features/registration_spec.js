var viewports =["macbook-15", "iphone-6"];

describe('Missguided Registration Page', () => {
    beforeEach(() => {
        cy.visit("customer/account/login/");
        cy.clearCookie('frontend');
    });    
    viewports.forEach( (viewport) => {   
        context('user can register on missguided', () => {
            it('should let a new user register', () => {
                cy.viewport(viewport);
                cy.visit("customer/account/login/");
                cy.get('.account-login__label--last').click();
                cy.loginPageRegisterFormfill({firstName: "FirstUserName"});
                cy.get('#register').click();
                cy.get('.success-msg span').should('have.text', "Thank you for registering with Missguided.");
                cy.clearCookies();
            });
        });

        context('invalid email address assertion in registartion on missguided', () => {
            it('should display error message when user enters invalid email address', () => {
                cy.viewport(viewport);
                cy.visit("customer/account/login/");
                cy.get('.account-login__label--last').click();
                cy.loginPageRegisterFormfill({email: 'missguided.com'}).type('{enter}');
                cy.get('#advice-validate-email-email').should('have.text', "Enter a valid email address");
            });
        });

        context('invalid DOB assertion in registration on missguided', () => {
            it('should display error message when user enters invalid DOB', () => {
                cy.viewport(viewport);
                cy.visit("customer/account/login/");
                cy.get('.account-login__label--last').click();
                cy.loginPageRegisterFormfill({dob: '01/02/1800'}).type('{enter}');
                cy.get('#advice-validate-date-birth_date').should('have.text', "Please enter a valid date");
            });
        });

        context('password & confrim password assertion in registration on missguided', () => {
            it('should display error message when password & confirm password are different', () => {
                cy.viewport(viewport);
                cy.visit("customer/account/login/");
                cy.get('.account-login__label--last').click();
                cy.loginPageRegisterFormfill({password : 'Manchester001', confirmation : 'Manchester000'});
                cy.get('#password').type('{enter}');
                cy.get('#advice-validate-cpassword-confirmation').should('have.text', "Passwords must match");
            });
        });

        context('User registration without subscription to emails', () => {
            it('should register successfully without subscribing to email', () => {
                cy.viewport(viewport);
                cy.visit("customer/account/login/");
                cy.get('.account-login__label--last').click();
                cy.loginPageRegisterFormfill();
                cy.get('#is_subscribed > span')
                  .should('have.text', "No Emails Thanks")
                  .click();
                cy.get('.account-login__register-section')
                  .should('have.text', "You are unsubscribed from Missguided emails")
                  .should('be.visible');  
                cy.get('#register').click();
                cy.get('.success-msg span').should('have.text', "Thank you for registering with Missguided.");
            });
        });
 
        context('required field assertion in registration page on missguided', ()=>{
            it('should display error mesasge when user tries to register by leaving any of the field as blank',()=>{
                cy.viewport(viewport); 
                cy.visit("customer/account/login/");
                cy.get('.account-login__label--last').click();
                cy.loginPageRegisterFormfill({firstName: '{backspace}',lastName: '{backspace}', email: '{backspace}', dob: '{backspace}' });
                cy.get('#register').click();
                cy.get('#advice-required-entry-firstname').should('have.text', "This is a required field.");
                cy.get('#advice-required-entry-lastname').should('have.text', "This is a required field.");
                cy.get('#advice-required-entry-email').should('have.text', "This is a required field.");
                cy.get('#advice-required-entry-birth_date').should('have.text', "This is a required field.");
            });
        });
    });
});



