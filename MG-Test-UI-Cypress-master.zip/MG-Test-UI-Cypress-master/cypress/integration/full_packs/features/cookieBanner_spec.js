beforeEach(()=>{
    cy.server();
});

var viewports =["macbook-15", "iphone-6"];

describe('Missguided Cookie Banner', ()=>{
    viewports.forEach((viewport)=>{
        context('Cookie banner at bottom of the page', ()=>{
            it('Cookie banner should be visible to user at bottom of the page', ()=>{
               cy.viewport(viewport);
               cy.visit('');
               cy.cookieBanner();
               cy.get('.cookie-banner__text > p')
                 .should('have.text', "Missguided uses cookies. Read more here")
            });
        });
        context('Close Cookie banner at the bottom of the page', ()=>{
            it('Cookie banner should not displayed once user clicks on x icon in cookie banner', ()=>{
                cy.viewport(viewport);
                cy.visit('');
                cy.closeCookieBanner();
            });
        });
    });

});