beforeEach( () => {
    cy.server();
});

var viewports =["macbook-15", "iphone-6+"];

describe('Missguided Main Menu', ()=>{
  viewports.forEach((viewport)=> {
    context('open and close the main menu', ()=> {
        it('by clicking on main menu it should appear and for next click menu should disappear', ()=> {
            cy.viewport(viewport);
            cy.visit('');
            cy.wait(5000); // by removing this wait this scenario will fail
            cy.open_main_menu();
            cy.close_main_menu();
            cy.open_main_menu();
            
        });
    });

    context('clicking on MG site  logo', ()=> {
       it('by clicking on site logo should navigates to the home page', ()=> {
            cy.viewport(viewport);
            cy.visit('/');
            cy.site_logo_redirect();
            cy.url().should("eq", Cypress.config("baseUrl") + "/");  
            
        });
    });

    context('MG home menu navigation', ()=> {
        it('by clicking on the home menu should redirect to the home page', ()=>{
            cy.viewport(viewport);
            cy.visit('/');
            cy.wait(5000);
            cy.open_main_menu();
            cy.home_menu_navigation();
            cy.url().should("eq", Cypress.config("baseUrl") + "/");  
        });
    });

    context('MG account menu navigation', ()=>{
        it('by clicking account menu should display the submenu',()=>{
             cy.viewport(viewport);
             cy.visit('');
             cy.wait(5000);
             cy.open_main_menu();
             cy.account_menu_navigation();
        });

    });

    context('MG header search icon', ()=>{
        xit('by clicking on search icon should display a form and based on user input should provide an appropraite result', ()=>{
             cy.viewport(viewport);
             cy.visit('');
             cy.search_icon();
        });
    });

    context('MG header guest customer wishlist navigation', ()=>{
        it('by clicking on wishlist icon should redirect the user to login page', ()=>{
             cy.viewport(viewport);
             cy.visit('');
             cy.wishlist_icon();
             cy.location().should((wishlistGuest) => {
                expect(wishlistGuest.href).to.include('/customer/account/login')
             });
        }); 
    });           
    context('MG header logged in customer wishlist navigation', ()=>{
        it('by clicking on wishlist icon should redirect the user to wishlist page', ()=>{
             cy.viewport(viewport);
             cy.visit('');
             cy.createUser();
             cy.wishlist_icon();
             cy.location().should((wishlist) => {
                expect(wishlist.href).to.include('/wishlist')
               })  
        });
    });

    context('MG header empty bag icon', ()=>{
        it('by clicking on empty bag icon in header user should see a toolip', ()=>{
            cy.viewport(viewport);
            cy.visit('');
            cy.empty_bag_icon();
            cy.get('#empty-bag__tooltip-text')
              .should('have.text', "\n    your bag is empty!continue shopping");
        });
    });

    context('MG header bag icon navigation', ()=>{
        it('by clicking on bag icon with an item in header should redirect to the checkout page', ()=>{
             cy.viewport(viewport);
             cy.visitProductPage();
             cy.addToBag();
             cy.visit('');
             cy.filled_bag_icon();
        });
    });

    context('MG header store switcher navigation', ()=>{
        it('by clicking on store switcher should display a modal with the list of stores', ()=>{
            cy.viewport(viewport);
            cy.visit('');
            cy.store_switcher();
        });
    });

    context('MG header main menu navigation without sub menu', ()=>{
        it('by clicking on the main menu it should redirect to the corresponding category page', ()=>{
            var menu = "Tall";
            cy.viewport(viewport);
            cy.visit('');
            cy.wait(5000);  // by removing this wait this scenario will fail
            cy.open_main_menu();
            cy.main_menu_nav_without_sub_menu(menu);
            var menuLower = menu.toLowerCase();
            cy.location().should((assert)=>{
              expect(assert.href).to.include(menuLower);  
              });
        });
    });

    context('MG header main menu navigation with sub menu', ()=>{
        it('by clicking on the main menu should display the sub menu option and by clicking any sub menu option should redirect to the corresponding category page', ()=>{
             var main = "Dresses";
             var subMenu = "Mini Dresses"
             cy.viewport(viewport);
             cy.visit('');
             cy.wait(5000); // by removing this wait this scenario will fail
             cy.open_main_menu();
             cy.main_menu_nav_without_sub_menu(main);
             cy.main_menu_nav_with_sub_menu(subMenu);
             cy.get('.category-intro__title')
               .should('have.text', subMenu);
        });
    });

  });

});
    
    
    

