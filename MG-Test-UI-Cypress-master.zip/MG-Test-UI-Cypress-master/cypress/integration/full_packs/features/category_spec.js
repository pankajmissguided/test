beforeEach( () => {
    cy.server();
});

var viewports =["macbook-15", "iphone-6"];

var position = Math.floor((Math.random() * 40) + 1);

describe('missguided category page',()=> {
  viewports.forEach((viewport)=> {
    context(viewport, () => {
      context('navigate to a product page from category page',() => {
          it('should allow user to navigate to product page from category page',()=>{
              cy.viewport(viewport);
              cy.visitCategoryPage();
              cy.selectProduct(position);
          });
      });

      context('navigate to a product page by loading more styles in category page', ()=>{
          it('should allow user to navigate to a product page by loading more styles in category page', ()=>{
            cy.viewport(viewport);
            cy.visitCategoryPage();
            cy.get('#category-products')
              .within(()=>{
                cy.get('.cascade__controls')
                  .should('have.text', "\n                \n                    Load more styles                \n                \n            ")
                  .click(); 
                  cy.get('.product-grid__search-results > li > .product-name', {timeout: 5000})
                    .then((noproducts)=>{
                      let num = noproducts;
                      var number = num.length;
                      cy.get('.cascade__label > .js-cascade-label-visible')
                        .should('have.text', number.toString());
                    });
              
              });
          
          });
      });
      
      context('back to top button in category page', ()=>{
          it('should take user to the top of category page', ()=>{
            cy.viewport(viewport);
            cy.visitCategoryPage();
            cy.get('.cascade__controls').scrollIntoView();
            cy.get('.back-to-top__link > .icon').click();
            cy.get('.site-logo')
              .should('be.visible');
          });
      });

    context('adding a product to wishlist from category page', ()=> {
        it('should allow a registered user to add a product to wishlist from category page', ()=> {
            cy.viewport(viewport);
            cy.createUser();
            cy.visitCategoryPage();
            cy.get('#category-products .product-grid__search-results > li > .price-wishlist-container > .button-container--wishlist')
              .then((categoryproducts)=>{
                let pro = categoryproducts;
                var selectOne = pro[Math.floor(Math.random() * pro.length)];
                cy.log(selectOne);
                cy.get('.product-grid__search-results > li')
                  .find(selectOne)
                  .click()
                  .within(()=> {
                    cy.get('.button--add-wishlist > .icon')
                      .click()
                      .should('be.visible');
                  });
              });
          });      
      
      });
      
      context('category title in category page', ()=>{
        it('user should see the category title in category page', ()=> {
          cy.viewport(viewport);
          cy.visitCategoryPage();
          cy.get('#category-title')
            .should('be.visible');
        });
      }); 
      
      context('colourways in category page', ()=>{
        it('by clicking on colourways of a product should redirect to the corresponding product page', ()=>{
          cy.viewport(viewport);
          cy.visitCategoryPage();
          cy.clickOnFirstColourwaysProduct();
        });
      });
    });  
  });
  
  context('macbook-15', () => { 
      context('Desktop sort by options in category page', ()=> {
        it('should allow user to select any sort by options in Desktop from the category page', ()=> {
          cy.viewport("macbook-15");
          cy.visitCategoryPage();
          cy.get("#js-sort-by")
            .should('have.text', "Sort By");
          cy.get(".sort-by")
            .should('have.text', "Most Wanted");
          cy.get(".sort-by > .icon")
            .click(); 
          cy.sortByFilter();
          cy.categoryProductAssertion();
                
          });
      });

      context('Desktop hide & Unhide the filter options in category page', ()=> {
        it('Should allow user to hide or unhide the filter options in category page', ()=> {
          cy.viewport("macbook-15");
          cy.visitCategoryPage();
          cy.get('.filter-toggle-wrap > .filter-toggle')
            .click();
          cy.get('.filter-group')
            .should('not.be.visible');
          cy.get('.filter-toggle-wrap > .filter-toggle', {timeout : 2000})
            .click();
          cy.get('.filter-group')
            .should('be.visible');    
        });

      });

      context('Desktop colour filter in the category page', ()=> {
        it('Should allow user to select a colour filter from the category page', ()=> {
          cy.viewport("macbook-15");
          cy.visitCategoryPage();
          cy.get('.filter-group--colour > .filter-title > .filter-title__text')
            .should('have.text', "COLOUR");
          cy.colourFilter();
          cy.get('.filter-group--colour > .nav-clear')
            .should('have.text', "\n                                Clear                            ");
          cy.categoryProductAssertion();
          cy.get('.filter-group--colour > .filter-title > .filter-arrow-wrap', {timeout: 10000})
            .click();
          cy.get('.filter-group--colour > .filter-group__content >', {timeout: 10000})
            .should('not.be.visible');
          cy.get('.filter-group--colour > .filter-title > .filter-arrow-wrap', {timeout: 10000})
            .click();
          cy.get('.filter-group--colour > .filter-group__content >', {timeout: 30000})
            .should('be.visible');

        });
            
      });

      context('Desktop size filter in the category page', ()=> {
        it('Should allow user to select a size filter from the category page', ()=> {
          cy.viewport("macbook-15");
          cy.visitCategoryPage();
          cy.get('.filter-group--size > .filter-title > .filter-title__text')
            .should('have.text', "Size");
          cy.sizeFilter();
          cy.get('.filter-group--size > .nav-clear')
            .should('have.text', "\n                                Clear                            ");
          cy.categoryProductAssertion();
          cy.get('.filter-group--size > .filter-title > .filter-arrow-wrap', {timeout: 10000})
            .click();
          cy.get('.filter-group--size > .filter-group__content >', {timeout: 10000})
            .should('not.be.visible');
          cy.get('.filter-group--size > .filter-title > .filter-arrow-wrap', {timeout: 10000})
            .click();
          cy.get('.filter-group--size > .filter-group__content >', {timeout: 30000})
            .should('be.visible');
        });
      });

      context('Desktop price filter in the category page', ()=> {
        xit('Should allow user to select price filter from the category page', ()=> {
          cy.viewport("macbook-15");
          cy.visitCategoryPage();
          cy.get('.filter-group--price-range > .filter-title > .filter-title__text') 
            .should('have.text', "PRICE RANGE") 
          cy.priceFilter();
          cy.get('.filter-group--price-range > .nav-clear', {timeout: 10000})
            .should('have.text', "\n                                Clear                            "); 
          cy.get('[data-index="0"]')
            .click({force:true});
          cy.categoryProductAssertion();
        });
      
      });

      context('Desktop applying colour, size, price & sort by filter at a time in category page', ()=> {
        xit('Should allow user to select all 4 filters at a time in category page', ()=> {
          //By applying all three filters (size, colour, price) getting an uncaught exception error in MG live
          cy.viewport("macbook-15");
          cy.visitCategoryPage();
          cy.colourFilter();
          cy.sizeFilter();
          cy.priceFilter();
          cy.get(".sort-by > .icon")
            .click();
          cy.sortByFilter();
        });
      });
    });

    context('iphone-6', () => {
      context('Mobile Sort by options in category page', ()=> {
        it('should allow user to select any sort by options in Mobile from the category page', ()=> {
          cy.viewport("iphone-6");
          cy.visitCategoryPage();
          cy.get(".filter-link--sort")
            .should('have.text', "Sort By")
            .click();
          cy.sortByFilter();
          cy.categoryProductAssertion();
        });
      });

      context('Mobile colour filter in the category page', ()=> {
        it('Should allow user to select colour filter from the category page', ()=> {
          cy.viewport("iphone-6");
          cy.visitCategoryPage();
          cy.mobileFilter();
          cy.get('.filter-group--colour > .filter-title > .filter-title__text')
            .should('have.text', "COLOUR");
          cy.colourFilter();
          cy.get('.filter-group--colour > .nav-clear', {timeout: 10000})
            .should('have.text', "\n                                Clear                            ");
          cy.applyMobileFilter();
          cy.categoryProductAssertion();
        });
      });

      context('Mobile size filter in the category page', ()=> {
        it('Should allow user to select size filter from the category page', ()=> {
          cy.viewport("iphone-6");
          cy.visitCategoryPage();
          cy.mobileFilter();
          cy.get('.filter-group--size > .filter-title > .filter-title__text')
            .should('have.text', "Size");
          cy.sizeFilter(); 
          cy.get('.filter-group--size > .nav-clear', {timeout: 10000})
            .should('have.text', "\n                                Clear                            ");  
          cy.applyMobileFilter();
          cy.categoryProductAssertion();  
        });
      });

      context('Mobile Price filter in the category page', ()=> {
        xit('Should allow user to select price filter from the category page', ()=> {
          cy.viewport("iphone-6");
          cy.visitCategoryPage();
          cy.get('.filter-group--price-range > .filter-title > .filter-title__text') 
            .should('have.text', "PRICE RANGE") 
          cy.mobileFilter();
          cy.priceFilter();
          cy.get('.filter-group--price-range > .nav-clear', {timeout: 10000})
            .should('have.text', "\n                                Clear                            ");
          cy.applyMobileFilter();
          cy.categoryProductAssertion(); 
        });
      });
      
      context('Mobile applying colour, size, price & sort by filter at a time in category page', ()=> {
        xit('Should allow user to select all 4 filters at a time in category page', ()=> {
          //By applying all three (size, colour, price) filters getting an uncaught exception error in MG live
          cy.viewport("iphone-6");
          cy.visitCategoryPage();
          cy.mobileFilter();
          cy.colourFilter();
          cy.sizeFilter();
          cy.priceFilter();
          cy.applyMobileFilter();
          cy.get(".filter-link--sort")
            .should('have.text', "Sort By")
            .click();
          cy.sortByFilter();
        });
      });
    });
    
});