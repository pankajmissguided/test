beforeEach( function () {
    cy.server();
});

describe('DCX virtual assistant integration', () => {
    context('Desktop user can see message of the day', () => {
        it('should display the message present in the response', () => {
            cy.viewport('macbook-15');
            let message = '**TEST DATA** \n\n Some Data Response'
            let output = [{
                "type": "answer",
                "text": message,
                "type": "answer",
                "links": [],
                "projectConstants": [],
                "dialogOptions": [],
                "metadata": {},
                "images": [],
                "videos": []
                }];
            cy.dcxMessageOfTheDayMock(output);
            cy.visit("/help/");
            cy.contains("Some Data Response");
        });
    });
 });