describe("ECT-187", () => {
    context("User on category page", () => {
        it("Should populate the dataLayer with the prodcut impression", () => {
            let productImpression = [];
            cy.visit('/dresses/mini-dresses');
            cy.window().then((win) => {
                win.dataLayer.forEach( (data) => {
                    if (data.event = 'productImpression'){
                        productImpression.push(data);
                    } else {
                        console.log("not impression");
                    }
                });
            console.log("PRODUCT IMPRESSION", productImpression);
            });
        });
    })
});