# Organising & Structuring Checks

## Folder Structure

```bash
# Examples of how to perform specific actions. NOT for executing.
./integration/examples/

# Full Spec files are stored in here. New test all go in this folder. This is the 100% folder
./integration/full_packs/

# Customised subsets of tests are placed in here. This is the 20% folder
./integration/subsets
```


When building checks, the below rules should be followed for weighting volume of tests for the various regions / websites. Magento at its core is very extensible and functional issues infrequently present themselves as regional specfic. Applying the law of diminishing returns (there is low value returned from the extra effort to automated the other regions) the below weighting for scenarios should be applied as a guideline.

| Type          | Functional %          | E2E % | Misc % |
| ------------- | -------------         | ----- | ------ |
| MG - UK	    | 100			        | 100	| 100	 |
| Mennace	    | 100			        | 100	| 100	 |
| MG - DE 	    | 20			        | 20	| 100	 |
| MG - !UK	    | 20			        | 100	| 100	 |


### 100% - Full packs

100% means that all the tests build should be working and executed on that regions.

### 20% - Subsets

20% is _figurative_. It means that only a smaller section of the tests built for the UK should be customised for other regions. Where a region breaks the rule and has diverging functionality, ensure this is covered full and not just a subset.

Taking this approach follows the Pareto Principle (80/20) https://en.wikipedia.org/wiki/Pareto_principle. 80% of the key functionality can be excercised by 20% of the scenarios.

### Example

**100% checks - UK**

- Test points for the registration feature:
    - Register valid user
    - Register valid user with marketing
    - Register valid user with ranges of email formats
    - Register valid user with varying complying passwords
    - User cannot register with not matching passwords
    - User cannot register with non-compliant e-mails
    - User cannot register with non-compliant passowrds
    - User cannot register missing first name field
    - User cannot register missing last name field
etc...

**20% checks - Non UK regions**

- Test points for the registration feature:
    - Register valid user
    - Register valid user with marketing
    - User cannot register with non-compliant passwords

#### Rational

Whilst the checks in the UK are valid on other regions, the code processing them is infact the same. This makes the maintaing the check less _valuable_ as it is testing risk already processed verified in other checks. However leaving the remaining few tests provides a sanity check that registration is functioning and has not regressed. 

### Other notes

Cypress is not a VISUAL testing tool in its current state. We are testing functionality rather than the aesthetics of the website. This means that in some cases a functional test may pass, where are in fact certain style sheets are broken. How to mitigate? Visual regression testing is a future soltuion we may want to invest it, however checking that a new feature 'looks and feels' as desired is something that can only be accomplished through exploration and investigation, not running a program.