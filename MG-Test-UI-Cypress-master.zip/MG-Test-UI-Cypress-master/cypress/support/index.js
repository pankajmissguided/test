// ***********************************************************
// This example support/index.js is processed and
// loaded automatically before your test files.
//
// This is a great place to put global configuration and
// behavior that modifies Cypress.
//
// You can change the location of this file or turn off
// automatically serving support files with the
// 'supportFile' configuration option.
//
// You can read more here:
// https://on.cypress.io/configuration
// ***********************************************************

// Import commands.js using ES2015 syntax:
import './commands'
import './pages/login'
import './pages/product'
import './pages/help'
import './pages/checkout'
import './pages/newsletter'
import './pages/category'
import './pages/GDPR'
import './pages/homePage'
import './pages/mainHeaderNav'
import './pages/cookieBanner'
import './requests/requestHelpers'
import './pages/mennacePages/mennaceE2e'



// Alternatively you can use CommonJS syntax:
// require('./commands')
