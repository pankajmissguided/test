import faker from "faker";
import * as _ from 'lodash';

Cypress.Commands.add('enterStripeDetails', (testCardData) => {
    let defaultTestCardData = {
        card: '4242424242424242',
        exp: '03/19',
        cvv: '123'
    };
    testCardData = _.merge(defaultTestCardData, testCardData);
    cy.get('.button--pay-by-card')
        .click();
    cy.get('#cryozonic_stripe_cc_number')
        .type(testCardData.card, {force: true});
    cy.get('#cc-exp')
        .type(testCardData.exp, {force: true});
    cy.get('#cryozonic_stripe_cc_cid')
        .type(testCardData.cvv, {force: true});
});

Cypress.Commands.add('enterCapturePlusData', (addressLine1) => {
    var addressLine1 = (addressLine1 === undefined) ? "75 trafford wharf" : addressLine1;
    let pcaFindResponse = {
        "Items":[
            {
                "Id":"GB|RM|A|50751214",
                "Type":"Address",
                "Text": addressLine1,
                "Highlight":"0-2,3-17,18-22",
                "Description":"Trafford Park, Manchester, M17 1ES"
            }
        ]
    };

    cy.route('POST', /checkout\/securecheckout\/saveShipping/).as('getShipping');
    cy.route('GET', /Capture\/Interactive\/Find/, pcaFindResponse);
    cy.get('#shipping\\:capture_plus')
        .type(addressLine1, {force: true, delay: 80})
        .should('have.value', addressLine1);
    cy.get('.pcaitem.pcafirstitem.pcaselected')
        .should(($pca) => {
            expect($pca.text()).to.match(new RegExp(addressLine1,"i"));
        })
    cy.get('#shipping\\:capture_plus')
        .type('{enter}');
});

Cypress.Commands.add('enterClickAndCollectInfo',(postcode)=> {
    var postcode = (postcode === undefined) ? "M171ES" : postcode;
    cy.get('#clickcollect\\:telephone')
        .type("07777777777", {force: true});
    cy.get('#clickcollect\\:postcode-field')
        .type(postcode, {force: true, delay: 80});
    cy.route('GET', /clickcollect\/results\/listnew\/postcode/).as('getCNCResults')
    cy.get('.click-collect__search-button')   
        .click();
    cy.wait('@getCNCResults', {timeout: {requestTimeout: 10000}})
        .then((xhr) => {
            expect(xhr.status).to.equal(200);
        });
});

Cypress.Commands.add('clickAndCollectStore',() => {
    cy.get('.click-collect__result > .click-collect__list > li ').then((stores) => {
      let store = stores;
      var selectStore = store[Math.floor(Math.random() * store.length)];
      console.log(selectStore);
      var c=3;
      for(var i=0; i<c; i++){
        cy.get('.click-collect__show-more').click();
        
    }
      cy.get('.click-collect__result > .click-collect__list')
        .find(selectStore)
        .click();
   });
});

Cypress.Commands.add('enterBillingAddress', (billingData) => {
    let billingUserData = {
        firstName: faker.name.firstName(),
        lastName: faker.name.lastName(),
        telephone: "07777777777",
        addressLine1: "75 Trafford Wharf"
    }
    billingData = _.merge(billingUserData, billingData);

    let pcaFindResponse = {
        "Items":[
            {
                "Id":"GB|RM|A|50751214",
                "Type":"Address",
                "Text": billingData.addressLine1,
                "Highlight":"0-2,3-17,18-22",
                "Description":"Trafford Park, Manchester, M17 1ES"
            }
        ]
    };

    cy.route('GET', /Capture\/Interactive\/Find/, pcaFindResponse);
    cy.get('#billing\\:firstname')
      .type(billingData.firstName, {force: true});
    cy.get('#billing\\:lastname')
      .type(billingData.lastName, {force: true});
    cy.get('#billing\\:telephone')  
      .type(billingData.telephone, {force: true});
    cy.get('#billing\\:capture_plus')
      .type(billingUserData.addressLine1, {force: true})
      .should('have.value', billingUserData.addressLine1);
    cy.get('.pcaitem.pcafirstitem.pcaselected')
      .should(($pca) => {
          expect($pca.text()).to.match(new RegExp(billingUserData.addressLine1,"i"));
      }) 
    cy.get('#billing\\:capture_plus')
      .type('{enter}');
});

Cypress.Commands.add('enterCheckoutUserData', (userData) => {
    let defaultUserData = {
        firstName: faker.name.firstName(),
        lastName: faker.name.lastName(),
        telephone: "07777777777"
    };
    userData = _.merge(defaultUserData, userData);
    cy.get('#shipping\\:firstname')
        .type(userData.firstName, {force: true});
    cy.get('#shipping\\:lastname')
        .type(userData.lastName, {force: true});
    cy.get('#shipping\\:telephone')
        .type(userData.telephone, {force: true});
});

Cypress.Commands.add('placeOrder', () => {
    cy.route('POST', /checkout\/securecheckout\/saveOrder\/form_key/).as('placeOrder');
    cy.route('POST', /securecheckout\/savePayment/).as('savePayment');
    cy.get('#paypal-save-button')
        .click();
    cy.wait('@savePayment')
        .then((savePayment) => {
            expect(savePayment.status).to.equal(200);
        });
    cy.wait('@placeOrder')
        .then((placeOrder) => {
            expect(placeOrder.status).to.equal(200);
        });
});

Cypress.Commands.add('addEmailForGuest', ()=>{
    cy.get('#lookup-email')
      .type(faker.name.firstName() + faker.name.lastName() + "@example.com");
    cy.get('#email-lookup-action')
      .click();
})

Cypress.Commands.add('chooseDeliveryOption', ()=>{
    cy.get('#co-shipping-method-form > ul > li')
      .then((options)=>{
          let option = options;
          var selectOption = option[Math.floor(Math.random() * option.length)];
          cy.get('#co-shipping-method-form')
            .find(selectOption)
            .click();
      });
});     