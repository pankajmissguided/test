Cypress.Commands.add('footer_subscription', (email) => {
    cy.route('POST', /ajax\/subscriber\/new/)
      .as('getNewsletter')
    cy.get('.footer')
      .within(()=> {
        cy.get('.js-newsletter-input')
          .type(email)
          .type('{enter}');
        });  
    cy.wait('@getNewsletter').then(function(xhr){
      expect(xhr.status).to.equal(200)
      expect(xhr.request.body).to.include('email', 'area_of_site', 'territory')
    });
});

Cypress.Commands.add('mainMenu_newsletter', ()=>{
  cy.get('.site-header__element--menu > .primary-nav-handle')
    .click({force : true}, {timeout : 5000});
  cy.get('.primary-nav__menu')
    .should('be.visible');
  cy.get('.primary-nav__fixed-item--last > .level0 > :nth-child(3) > a')
    .should('have.text', "Newsletter Signup")
    .click({force : true});
});

Cypress.Commands.add('newsletter_subscription_mainMenu', (email)=>{
  cy.route('POST', /ajax\/subscriber\/new/)
    .as('getNewsletter')
  cy.get('.newsletter-overlay-content')
    .should('be.visible');
  cy.get('.newsletter-overlay-content > .form__newsletter > #newsletter-validate-detail > fieldset > .form__list > .form__field > .form__input > .left > .newsletter-input')
    .type(email)
    .type('{enter}');
  cy.wait('@getNewsletter').then(function(xhr){
      expect(xhr.status).to.equal(200)
      expect(xhr.request.body).to.include('email', 'area_of_site', 'territory')
    });  
});







