Cypress.Commands.add('dcxMessageOfTheDayMock', (outputParts) => {
    let stubUrl = "https://missguided-missguided.digitalcx.com/event/message_of_the_day?minFaqs=1&maxFaqs=3&apiKey=05eedaf2-fa52-43e1-9937-be4d4c315218&culture=en&dim.Territory=UK";
    let responseData = {
        "outputs": [
          {
            "outputId": 0,
            "kbaId": 33,
            "interactionValue": "message_of_the_day",
            "isDefault": true,
            "dimensionValues": [
              [
                "any"
              ]
            ],
            "outputParts": outputParts,
            "kbaCategories": []
          }
        ],
        "sessionId": "12144110-d4c4-4a8a-a060-e62337ed1785",
        "interactionId": "efc92b7f-8b87-468e-8c99-5e60e15e52b5",
        "culture": "en"
    };
    cy.route("GET", stubUrl, JSON.stringify(responseData));
});