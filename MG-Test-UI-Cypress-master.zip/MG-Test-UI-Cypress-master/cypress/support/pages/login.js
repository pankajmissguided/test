import faker from "faker";
import * as _ from 'lodash';
import { clearCookieBanner } from "./helpers.js";

// Add form fill commands login page

Cypress.Commands.add('loginPageRegisterFormfill', (userData) => {
    let defaultUserData = {
        firstName: faker.name.firstName(),
        lastName: faker.name.lastName(),
        email: faker.name.firstName() + faker.name.lastName() + '@example.com',
        dob: '01/01/1991',
        password: 'Tester01',
        confirmation: 'Tester01'
    }
    userData = _.merge(defaultUserData, userData);
   cy.get('#firstname').type(userData.firstName, {force: true});
    cy.get('#lastname').type(userData.lastName, {force: true});
    cy.get('#birth_date').type(userData.dob, {force: true});
    cy.get('#email').type(userData.email, {force: true});
    cy.get('#password').type(userData.password, {force: true});
    cy.get('#confirmation').type(userData.confirmation, {force: true});
});

Cypress.Commands.add('visitLoginPage', (region) => {
    cy.fixture('websiteUrls.json').as('urls');
    if (region == undefined) {
        cy.visit("/customer/account/login/");
    } else {
        cy.get('@urls').then((urls) => {
            cy.visit(urls[region] + "/customer/account/login/");
        });
    }
    clearCookieBanner();
});
