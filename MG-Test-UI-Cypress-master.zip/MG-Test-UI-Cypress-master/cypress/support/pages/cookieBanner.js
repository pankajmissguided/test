Cypress.Commands.add('cookieBanner', ()=>{
    cy.get('.cookie-banner')
      .should('be.visible');
    cy.get('.cookie-banner__text')
      .should('be.visible');
    cy.get('.cookie-banner__text > p > a')
      .click();
    cy.url().should('include', "/cookies-policy");
})

Cypress.Commands.add('closeCookieBanner', ()=>{
    cy.get('.icon--cross')
      .click();
    cy.get('.cookie-banner')
      .should('not.be.visible');
    cy.visitProductPage();
    cy.get('.cookie-banner')
      .should('not.be.visible');
});
