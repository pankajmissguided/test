export function clearCookieBanner() {
    let cookiePresent = false;
    cy.getCookies()
            .then((cookies) => {
                cookies.forEach((cookie) => {
                    if (cookie.name === "MG_cookiesAccepted" && cookie.value === 'true'){
                        cookiePresent = true;
                    }
                });
            })
            .then(() => {
                if (!cookiePresent) {
                    cy.get('.js-cookie-agree > .icon')
                    .click({force: true});
                }
            })
}