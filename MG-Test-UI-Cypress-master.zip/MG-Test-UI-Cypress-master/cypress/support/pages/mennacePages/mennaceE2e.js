Cypress.Commands.add('mennaceRegistration', ()=>{
    cy.get('.account-login__label--last')
      .click();
    cy.loginPageRegisterFormfill();
    cy.get('#register')
      .click();
    cy.get('.success-msg span').should('have.text', "Thank you for registering with Mennace.");
})

