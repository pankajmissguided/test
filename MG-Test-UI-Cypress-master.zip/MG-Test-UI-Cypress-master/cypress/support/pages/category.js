import { clearCookieBanner } from "./helpers.js";

Cypress.Commands.add('visitCategoryPage', (region) => {
    cy.fixture('categoryData.json').then((data) => {
        cy.fixture('websiteUrls.json').as('urls');
        if (region == undefined) {
            cy.visit(data.theWorks.uk);
        } else {
            cy.get('@urls').then((urls) => {
                url = urls[region];
                cy.visit(url + data.theWorks[region]);
            });
        }
        clearCookieBanner();
    });
});
// The below is to select a colour filter in both desktop & mobile
Cypress.Commands.add('colourFilter', ()=> {
    cy.get('.filter-group--colour > .filter-group__content > .block-layered-nav-filter > ul > li')
      .then((colours)=> {
        let colour = colours;
        var selectColour = colour[Math.floor(Math.random() * colour.length)];
        console.log(selectColour);
        cy.get('.block-layered-nav-filter > ul')
          .find(selectColour)
          .click();
      });  
    
});
// The below is to select the size filter in both desktop & mobile
Cypress.Commands.add('sizeFilter', ()=> {
    cy.get('.filter-group--size > .filter-group__content > .block-layered-nav-filter > ul > li')
      .then((sizes)=> {
        let size = sizes;
        var selectSizeFilter = size[Math.floor(Math.random() * size.length)];
        console.log(selectSizeFilter); 
        cy.get('.block-layered-nav-filter > ul')
          .find(selectSizeFilter)
          .click();
      });
});
// The below is to select the price filter in both desktop & mobile
Cypress.Commands.add('priceFilter', ()=> {
    var minimum = Math.floor(Math.random() * 20);
    cy.get('#price-input-low')
      .click()
      .type('{backspace}')
      .type(minimum)
      .type('{enter}');
     
});
// The below is to select the sort by option in both desktop & mobile
Cypress.Commands.add('sortByFilter', ()=> {
    cy.get(".sort-by-scroll > ul > li")
      .then((sortBy) => {
        let sortByOptions = sortBy;
        var selectSortBy =  sortByOptions[Math.floor(Math.random() * sortByOptions.length)];
        console.log(selectSortBy);
        cy.get(".sort-by-scroll > ul")
          .find(selectSortBy)
          .click();
       });
})
// The below is to click on filter option in mobile
Cypress.Commands.add('mobileFilter', ()=> {
    cy.get('.filter-refine > .filter-link__inner')
      .click();
})
// The below is to apply filter in mobile once the size / price / price filter
Cypress.Commands.add('applyMobileFilter', ()=> {
    cy.get('.filter-apply-all > .filter-action__inner')
      .click();
})
// The below is to assert products are displayed once the filters are applied
Cypress.Commands.add('categoryProductAssertion', ()=> {
    cy.get('#category-products .product-grid__search-results > li')
      .should('be.visible'); 
})

// The below is to select a product from category page
Cypress.Commands.add('selectProduct', (position) =>{
    let productId;            
    cy.get('.product-grid__search-results > li:nth-child(' + position + ')').then(($product)=>{
      productId = $product.attr('data-product-id')
    });
    cy.get('.product-grid__search-results > li:nth-child(' + position + ') .product-name', {timeout: 5000})
      .click();
    cy.get('#product_addtocart_form > div.no-display > input[type="hidden"]:nth-child(1)').then(($element) => {
      expect($element.val()).to.eq(productId);
    });
});

Cypress.Commands.add('clickOnFirstColourwaysProduct', ()=>{
    let product1;
    let product2;
    cy.get('.more-colours')
      .first()
      .click();
    cy.get('.product-essential__name')
      .invoke('text')
      .then((productName)=>{
        console.log(productName);
        product1 = productName;
    });
    cy.get('#product-options > :nth-child(2)')
      .should('be.visible');
    cy.get('#product-options > :nth-child(2) > .product-options__configure--product-colour > .product-options__configure-option > ul > li')
      .then((colourLists)=>{
        //var randomNumber = Math.floor(Math.random() * colourLists.length)+1; 
       // var selectColourList= colourLists[randomNumber]; // removed as using value of 1 for now
       var selectColourList= colourLists[1];
        cy.log(selectColourList);
        cy.get('#product-options > :nth-child(2)')
          .find(selectColourList)
          .click();
        cy.get('.product-essential__name')
          .invoke('text')
          .then((productName2)=>{
            console.log(productName2);
            product2 = productName2; 
          });
        cy.then(()=>{  
          expect(product1).to.not.equal(product2);
        }); 
    cy.addToBag();
  });   
});
    



