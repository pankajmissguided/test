import { clearCookieBanner } from "./helpers.js";

Cypress.Commands.add('visitProductPage', (region) => {
    cy.fixture('productData.json').then((data) => {
        cy.fixture('websiteUrls.json').as('urls')

        if (region == undefined) {
            cy.visit(data.theWorks.uk);
        } else {
            cy.get('@urls').then((urls) => {
                cy.visit(urls[region] + data.theWorks[region]);
            });
        }
        clearCookieBanner();
    });
});

Cypress.Commands.add('addToBag', () => {
    cy.route('POST', /ajax\/cart\/add/)
        .as('getLogin')
    cy.get('#add-to-cart')
        .click();
    cy.wait('@getLogin').then(function(xhr){
        expect(xhr.status).to.equal(200);
    });
});
