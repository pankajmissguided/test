
Cypress.Commands.add('open_main_menu', () => {
  cy.get('.site-header__element--menu > .primary-nav-handle')
    .click({force : true}, {timeout : 5000});
  cy.get('.primary-nav__menu')
    .should('be.visible');
});

Cypress.Commands.add('close_main_menu', () => {
   cy.get('.site-header__element--menu > .primary-nav-handle')
     .click({force : true});
   cy.get('.primary_nav_menu')
     .should('not.be.visible'); 
})

Cypress.Commands.add('site_logo_redirect', ()=> {
   cy.get('.site-header__element--logo')
     .click();
   
})

Cypress.Commands.add('home_menu_navigation', ()=>{
   cy.get('.nav-0 > .level-top > .icon')
     .should('be.visible');
   cy.get('.nav-0 > .level-top > span')
     .click({force : true});
});

Cypress.Commands.add('account_menu_navigation', ()=>{
    cy.get('.primary-nav__fixed-item--last > .level-top > .icon')
      .should('be.visible');
    cy.get('.primary-nav__fixed-item--last > .level-top > span')
      .click({force : true});
    cy.get('.primary-nav__fixed-item--last > .level0 > :nth-child(2) > a')
      .should('be.visible');
    cy.get('.primary-nav__fixed-item--last > .level0 > :nth-child(3) > a')
      .should('be.visible');    
    cy.get('.primary-nav__fixed-item--last > .level0 > :nth-child(1) > a')
      .click({force:true});
    cy.location().should((login) => {
        expect(login.href).to.include('/customer/account/login')
      })
});

Cypress.Commands.add('search_icon', ()=>{
   cy.get('.search-form__handle > .icon')
     .click();
   cy.get('#search_mini_form')
     .should('be.visible');
   cy.get('#search')
     .type('red dresses');
   cy.get('.search-form__button')
     .click(); 
   cy.location().should((search) => {
      expect(search.href).to.include('/catalogsearch/result/?')
      });  
});

Cypress.Commands.add('wishlist_icon', ()=>{
   cy.get('.mini-wishlist__link > .icon')
     .should('be.visible');
   cy.get('.mini-wishlist__link')
     .click();
});

Cypress.Commands.add('empty_bag_icon', ()=>{
   cy.get('.mini-bag__link > .icon')
     .should('be.visible');
   cy.get('.mini-bag__link')
     .trigger('mouseover');  
});

Cypress.Commands.add('filled_bag_icon', ()=>{
   cy.get('.mini-bag__item-qty')
     .should('be.visible');
   cy.get('.mini-bag__link')
     .trigger('mouseover');
   cy.get('.mini-bag__item-list')
     .should('be.visible');
   cy.get('.mini-bag__dropdown__actions')
     .should('have.text', "\n                                        View Bag/Pay Securely\n                ")
     .click();
   cy.location().should((checkout)=>{
     expect(checkout.href).to.include('/checkout/securecheckout')
     });     

});

Cypress.Commands.add('store_switcher', ()=>{
   cy.get('.site-header__element--store-switcher')
     .click();
   cy.get('.modal--store-switcher')
     .should('be.visible');
   cy.get('.store-switcher > .store-currency-switcher__title')
     .should('have.text', "Other country sites:Other country sites:")
   cy.get('.store-switcher > .store-currency-switcher__item > a > .store-switcher__store-inner > .store-switcher__store-code')
     .then((stores)=>{
       let store = stores;
       var selectOneStore = store[Math.floor(Math.random() * store.length)];
       var innerStore = selectOneStore.innerHTML;
       cy.get('.store-switcher')
         .find(selectOneStore)
         .scrollIntoView()
         .click({force : true});
       cy.location().should((storeUrl)=>{
         expect(storeUrl.href).to.include(innerStore);
         });    
      }); 
});

  
Cypress.Commands.add('main_menu_nav_without_sub_menu', (menuName) => { 
  cy.get('#nav > .primary-nav__menu').within(()=>{
     cy.get('.level0 > a')
       .contains(menuName)
       .click({force : true});
    })
});

Cypress.Commands.add('main_menu_nav_with_sub_menu', (subMenuName) => {
  cy.get('.menu-active')
    .should('be.visible'); 
  cy.get('.menu-active').within(()=>{
     cy.get('.level1 > a')
       .contains(subMenuName)
       .click({force : true});
  });
});
 


  
      
      












