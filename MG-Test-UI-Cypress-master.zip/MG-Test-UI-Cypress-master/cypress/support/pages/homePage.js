import { clearCookieBanner } from "./helpers.js";

Cypress.Commands.add('visitHomePage', (region) => {
    cy.fixture('websiteUrls.json').as('urls');
    if (region == undefined) {
        cy.visit("/");
    } else {
        cy.get('@urls').then((urls) => {
            cy.visit(urls[region]);
        });
    }
    clearCookieBanner();
    
});
