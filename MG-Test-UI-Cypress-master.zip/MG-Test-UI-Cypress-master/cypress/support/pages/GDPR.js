Cypress.Commands.add('cmsPage', ()=>{
    cy.get(':nth-child(3) > .table > tbody > :nth-child(7) > td > span > .privacy-link')
      .invoke('removeAttr', 'target')
      .click();
    cy.url().should('include', "privacy-policy")
});

Cypress.Commands.add('gdprCheckoutMessage', ()=>{
    cy.addToBag();
    cy.get('.mini-bag__link')
      .click();
    cy.url().should('include', "/checkout/securecheckout");
    cy.get('.order-summary__gdpr-information-content > p')
      .should('be.visible');
    cy.wait(5000);  // by removing this wait will fail the following steps
    cy.get('.gdpr-read-more-link')
      .click({force : true}, {timeout : 5000});
    cy.get('.gdpr-read-more > :nth-child(3) > a')
      .invoke('removeAttr', 'target')
      .click({force : true}); 
    cy.url().should('include', "/privacy-notices");   
});