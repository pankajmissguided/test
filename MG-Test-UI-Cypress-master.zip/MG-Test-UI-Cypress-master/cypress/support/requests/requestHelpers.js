import faker from "faker";
import * as _ from 'lodash';
import cheerio from 'cheerio';

Cypress.Commands.add('createUser', (userData) => {
    let defaultUserData = {
        success_url: '',
        error_url: '',
        firstname: faker.name.firstName(),
        lastname: faker.name.lastName(),
        email: faker.name.firstName() + faker.name.lastName() + '@example.com', 
        day: '01',
        day_select: '1',
        month: '06',
        month_select: '6',
        year: '1988',
        year_select: '1988',
        dob: '01/01/1970',
        password: 'Tester01',
        confirmation: 'Tester01'
    };
    userData = _.merge(defaultUserData, userData);

    cy.request({method: 'GET', url: '/customer/account/create'}).then((resp) => {
        var cheerio = require('cheerio'),
        $ = cheerio.load(resp.body);
        let result = $('#form-validate [name="form_key"]').val();
        userData.form_key = result;
        cy.request({method: 'POST', url: '/customer/account/createpost/', body: userData, form: true});
    });
});

Cypress.Commands.add('addProductToBag', (productData) => {
    cy.fixture('productData.json').then((data) => {
        let defaultProductData = {
            product: data.theWorks.id,
            related_product: "",
        };
        
        defaultProductData[`super_attribute[${data.theWorks.attributeSet}]`] = data.theWorks.inStockAttributes[0];

        productData = _.merge(defaultProductData, productData);
        
        cy.request({
            method: 'POST',
            url: '/ajax/cart/add/',
            body: productData,
            headers: {
                "X-Requested-With": "XMLHttpRequest"
            },
            form: true
        });
    });
});

Cypress.Commands.add('addUnicornToBag', () => {
    cy.fixture('productData.json').then((data) => {
        cy.request({
            method: 'POST',
            url: '/ajax/cart/add/',
            body: {
                product: data.unicorn.id,
                related_product: "",
                input15: "on"
            },
            headers: {
                "X-Requested-With": "XMLHttpRequest"
            },
            form: true
        });
    });
});